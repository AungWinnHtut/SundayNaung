/** Automatically generated file. DO NOT MODIFY */
package com.engineer4myanmar.sundaynaungtest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}